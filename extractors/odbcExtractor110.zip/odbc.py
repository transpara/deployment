
#
#   ODBC data gatherer for tStore
#
#   Run one or more SQL queries against ODBC data sources.
#   Uses specific decorators to label the colums in the results.
#   Sends the data to tStore using the output_tstore.py module
#   (provides buffering)
#
#   To Do:
#       query column alias validations - reserved words
#       handle NaN and None for ANY column value (?how?)
#       verify that query is ordered by time desc?
#       no need to save the buffer if it was empty last time you save it and still empty
#
#   1.0.0
#       skip queries that are not "enabled"
#   0.9.8
#       move to connect string instead of user/pass
#   0.9.7
#       use credentials with DSN if provided
#       trap cases where the DSN has become invalid because it was changed in the form
#       (or if it has been deleted in Windows ODBC)
#       two different types of authentication with username/password
#   0.9.0
#       when testing a query, return LAST_DATA_TIME with what it WOULD be updated to be
#       connect using DSN as string
#       query column alias validations - required decorators
#       verify query has one and only one time and at least one field
#       compare and update last_data_time using UTC
#   0.8.0
#       log errors to windows event log
#       loadDB each cycle to reflect changes to the DB in the execution
#       (maybe this should be every N cycles?)
#       query DB is now a list, not a dictionary
#       nope, it's a dictionary again
#   0.7.0
#       graceful handling of SQL error
#       dictionary of connections
#       do not reconnect if already connected
#       store DSN in odbc.db
#       connect via DSN not connect string
#       if no database found, exit gracefully
#       specify path for buffer file as parameter
#       provide reschedule_interval for each query
#       load query database (if present) on startup
#       first draft FastPI
#   0.6.6
#       record timestamp of most recent data retrieved
#       record time of last execution
#       save list of queries and metadata to disk
#
#

import pyodbc
import platform
import json
from datetime import datetime, timedelta
from dateutil import tz
import signal
import sys
import time
import dateutil
import pickle
# import win32evtlogutil
# import win32evtlog
# import win32security
# import win32api
# import win32con

import config
import output_tstore
import argparse

# OUR GLOBAL VARIABLES
QID = 0
QUERIES = {}
ODBC_CYCLE = 60 # SECONDS
CONNECTIONS = {}
VERSION = "1.1.0"

# global substitution variables, available to all queries
HOST = platform.node()

# these are initialized, but can change over time
LAST_DATA_TIME = datetime.now() - timedelta(minutes=5)


tz_local = dateutil.tz.tzlocal()
tz_utc = dateutil.tz.tzutc()

def graceful(signal,frame):
    config.TIMER.stop()
    try:
        config.MUTEX.release()
    except:
        pass
    sys.exit(0)
    return

signal.signal(signal.SIGINT, graceful)


# we pass in a dictionary which is within a list (not a deep copy)
def xQuery(query,latestTimestamp):
    query['last_data'] = latestTimestamp
    query['last_execution'] = datetime.now().replace(microsecond=0)
    return

# load the database of SQL queries and metadata
def loadDB():
    try:
        f = open('app/data/odbc.db','rb')
        queries = pickle.load(f)
        f.close()
    except:
        return {}
    return queries

##########################################################################
############################# CONNECT ####################################
##########################################################################
def connect(cstr):
    try:
        cnxn=pyodbc.connect(cstr)
        cnxn.setdecoding(pyodbc.SQL_WCHAR, encoding='utf-8')
        cnxn.setencoding(encoding='utf-8')
        cursor=cnxn.cursor()
        return cnxn,cursor
    except Exception as ex1:
        print("{}".format(ex1))
        return None, None
        
def disconnect(connection,cursor):
    try:
        cursor.close()
    except:
        pass
        
    try:
        connection.close()
    except:
        pass
       
        
##########################################################################             
############################# LIST TABLES ################################
##########################################################################       
    
def listTables(cstr):
    cxn,cur = connect(cstr)
    
    if cur == None:
        return "Invalid connection",[]
        
    tables = []
    for row in cur.tables():
        tables.append(row.table_name)    
                
    disconnect(cxn,cur)

    return msg,tables

def testDSN(cstr):   
    msg = ""
    try:
        tempcnxn=pyodbc.connect(cstr)
        tempcnxn.close()
        return {"status" : True }
    except Exception as er1:
        msg += "{}".format(er1)
        return {"status" : False, "response" : msg }  

def listDrivers():
    return pyodbc.drivers()   


##########################################################################
################################# TEST EXECUTE ###########################
##########################################################################
def testExecute(cstr,query):
    
    testSamples = []
    
    # these are initialized, but can change over time
    LAST_DATA_TIME = datetime.now() - timedelta(minutes=5)
    LAST_DATA_TIME = LAST_DATA_TIME.astimezone(tz_utc)
    
    connection,cursor = connect(cstr)
    
    if connection is None:
        return [],[],[],[],[],"CSTR not valid."     
 
    # this is tricky as shit... the query is an F string with arbitrary substitution parameters
    try:
        query = eval("f'''{}'''".format(query))
    except:
        disconnect(connection,cursor)
        return [],[],[],[],[],"Could not evaluate query."        
    
    try:
        response = cursor.execute(query)        
    except Exception as ex:
        print('Error executing query - {}'.format(ex))
        disconnect(connection,cursor)        
        return [],[],[],[],[],"{}".format(ex)
  
    if cursor.description is None:
        print('Error executing query. No columns selected')
        disconnect(connection,cursor)
        return [],[],[],[],[],"Invalid Query. No columns selected."

    cols = []
    for column in cursor.description:
        try:
           cols.append(column[0])
        except:
            pass
    ncols = len(cols)

    maxTextRows = 5
    rowCount = 0
    rows = []
    print(rows)
    for row in cursor:
        lr= list(row)
        
        fields = {}
        tags = {}
        sample = {}
        measurement = ""   
        
        for i in range(0,ncols):
            alias = cols[i]
            col_value = lr[i]
             
            
            split_alias = alias.split(':')
            if len(split_alias) != 2:        
                disconnect(connection,cursor)        
                return [],[],[],[],[],"Invalid/missing column alias."
            alias_type = split_alias[0]
            alias_name = split_alias[1]
            if alias_type == 't':
                ts = col_value.replace(tzinfo=tz_utc)
                rawTs = ts
                ts = ts.astimezone(tz_local)
                ts = int(datetime.timestamp(ts))
            elif alias_type == 'm':
                # measurement = alias_name
                measurement = str(col_value)
            elif alias_type == 'f':
                # check that it's numeric? fields have to be for promscale
                try:
                    fields[alias_name] = float(col_value)
                except:
                    disconnect(connection,cursor)
                    return [],[],[],[],[],"Non-numeric value cannot be used as a field."
            elif alias_type == 'l':
                tags[alias_name] = str(col_value)
            else:
                disconnect(connection,cursor)
                return [],[],[],[],[],"Invalid/missing column alias."                
                

        sample['fields'] = fields
        sample['tags'] = tags
        sample['timestamp'] = ts
        sample['name'] = measurement
        testSamples.append(sample)
        
        #err, processedLine = output_tstore.processLine(json.dumps(sample),False)
        #print(processedLine)
        
        if rowCount > maxTextRows:
            break
        rows.append(list(row))
        rowCount += 1
   
    subvs = []
    
    now = datetime.now().astimezone(tz_utc)
    
    # let's also return the substitution variables
    subvs.append({"{SYSTEM_TIME}" : '"{}"'.format(now) } )
    subvs.append({"{HOST}" : '"{}"'.format(HOST)})  
    subvs.append({"{LAST_DATA_TIME}" : '"{}"'.format(LAST_DATA_TIME)})
   
    disconnect(connection,cursor)
    return cols,rows,subvs,query,testSamples,None

##################################### MAIN

if __name__ == "__main__":
       
    flags = argparse.ArgumentParser()
    flags.add_argument('-u','--url',dest='url',type=str,required=True)
    flags.add_argument('-t','--metric_type',dest='metric_type',type=int,required=True)
    flags.add_argument('-d','--debug',dest='debug',action='store_true')
    flags.add_argument('-q','--queue_depth',dest='queue_depth',default=10000)
    flags.add_argument('-e','--expire_seconds',type=int,dest='expire_seconds',default=120)
    flags.add_argument('-i','--identity',type=str,dest='identity',default='odbcExtractor')
    flags.add_argument('-s','--statistics',dest='statistics',action='store_true')

    # if the arguments are not correct, the program will exit with a message
    args = flags.parse_args()

    # GLOBAL VARIABLES SHARED WITH OUTPUT_TSTORE
    config.TSTORE_API_URL = args.url
    config.DEBUG = (args.debug == True)
    config.METRIC_TYPE = args.metric_type
    config.QUEUE_DEPTH = args.queue_depth
    config.EXPIRE_SECONDS = args.expire_seconds
    config.IDENTITY=args.identity
    config.STATISTICS=args.statistics

    ##### start the timer based on EXPIRE_SECONDS (to write chunks to tStore)
    output_tstore.startTimer()
    
    #### initialize to something
    connection = None
    cursor = None

    while (True):
        
        QUERIES = loadDB()
        
        if len(QUERIES) == 0:
            print('No queries to process.')

        for k,qd in QUERIES.items():
            
            try:
                enabled = qd['enabled']
            except:
                enabled = False
            
            if (not enabled):
                continue
            
            now = datetime.now()

            LAST_DATA_TIME = qd['last_data']
            if LAST_DATA_TIME is None:
                LAST_DATA_TIME = datetime.now() - timedelta(minutes=5)
            LAST_DATA_TIME = LAST_DATA_TIME.astimezone(tz_utc)

            cstr = qd['cstr']
            connection, cursor = connect(cstr)
        
            # this is tricky as shit... the query is an F string with arbitrary substitution parameters
            query = eval("f'''{}'''".format(qd['query']))
            # print(query)
            interval = qd['interval']
            last_execution = qd['last_execution']

            # if it's not time to execute this specific query, don't    
            try:
                if (now-last_execution) < interval:
                    disconnect(connection,cursor)
                    continue
            except:
                pass

            # execute the query
            try:
                cursor.execute(query)        
            except Exception as ex:
                print('Error executing query - {}'.format(ex))
                disconnect(connection,cursor)
                continue

            cols = [column[0] for column in cursor.description]
            ncols = len(cols)
            
            for row in cursor:
                lr= list(row)
                
                fields = {}
                tags = {}
                sample = {}
                measurement = ""
                
                # process each column with its value
                for i in range(0,ncols):
                    alias = cols[i]
                    col_value = lr[i]

                    split_alias = alias.split(':')
                    if len(split_alias) != 2:
                        output_tstore.debugPrint(f'invalid column alias {alias}')
                    alias_type = split_alias[0]
                    alias_name = split_alias[1]
                    if alias_type == 't':
                        ts = col_value.replace(tzinfo=tz_utc)
                        rawTs = ts
                        ts = ts.astimezone(tz_local)
                        ts = int(datetime.timestamp(ts))
                    elif alias_type == 'm':
                        measurement = str(col_value)
                    elif alias_type == 'f':
                        # fields have to be for promscale
                        try:
                            fields[alias_name] = float(col_value)
                        except:
                            print('Non-numeric value cannot be used as field')
                            break

                    elif alias_type == 'l':
                        tags[alias_name] = str(col_value)
                        
                sample['fields'] = fields
                sample['tags'] = tags
                sample['timestamp'] = ts
                sample['name'] = measurement
                                
                output_tstore.processLine(json.dumps(sample))
                if rawTs > LAST_DATA_TIME:
                    LAST_DATA_TIME = rawTs

            xQuery(qd,LAST_DATA_TIME)
            sys.stdout.flush()
        
        disconnect(connection,cursor) 
        time.sleep(ODBC_CYCLE)