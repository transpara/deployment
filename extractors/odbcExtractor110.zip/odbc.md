
# ODBC Extractor (tODBC)

**Transpara tStore Suite**

## Overview

**We use two terms when we talk about moving data from place to place**

* **Interface**
  * **An interface is a connection for on-demand gathering of data. This is the long-standing terminology used by for VisualKPI.**
  * **Note that some data is “cached” in VisualKPI for performance or other reasons. This is not the same as long-term storage; the cache is only available to specific applications.**
* **Extractor**
  * **This is the term that we use for moving data from a foreign system to tStore for longer-term storage and general availability of the data.**

## ODBC

**Microsoft Open Database Connectivity is a standard, widely-adopted software layer that provides SQL access to a huge variety of databases, systems and equipment.**

**The Transpara ODBC extractor leverages this capability to pull data, on a schedule, from any configured data source, and deliver the data to tStore.**

**The Transpara ODBC Extractor consists of:**

* **a graphical user interface for construction, testing and configuration of ODBC queries**
* **a Windows service that supports the above GUI**
* **a Windows service that executes the queries**

**Note:**

**Tested using:**

* **Python 3.9.1**
* **Python 3.10.2**

# Transpara ODBC Installation

**This installation procedure is for the interim bridge release of the Transpara ODBC Extractor. The production installation procedure will be integrated with the server manager.**

**The INTERIM tODBC installation kit is a single zip file with the following contents:**

| **File**                                          | **Description**                                                                                                |
| ------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------- |
| **Extractor Manager (and associated DLLs, etc.)** | **The INTERIM GUI for configuring and testing ODBC queries.**                                                  |
| **config.py**                                     | **Internal module for Python script configuration.**                                                           |
| **install_services.bat**                          | **Batch file to install Windows services.**                                                                    |
| **nssm.exe**                                      | **Executable to support running Python scripts as Windows services.**                                          |
| **odbc.md**                                       | **This document**                                                                                              |
| **odbc.py**                                       | **The Transpara ODBC Extractor**                                                                               |
| **odbc_api.py**                                   | **The API that supports the INTERIM GUI and targeted final GUI.**                                              |
| **output_tstore.py**                              | **The Python module shared by all Transpara Extractors for delivering data to tStore through the tStore API.** |
| **python*.exe**                                     | **For convenience, one or more compatible versions of Python for Windows.**                                    |
| **requirements.txt**                              | **a list of required Python modules for use with pip install -r**                                              |

### Preparation

* **Identify target tStore host ("tStore")**
  * **reachable by network from the ODBC Extractor node**
  * **allows connections on the tStore API Port (default 10001)**
* **Identify Windows server for the ODBC Extractor ("Windows Server")**
  * **can reach the tStore instance by network**
  * **service account**
    * **administrator access**
    * **interactive login rights (during the installation, at least)**
  * **can reach any required ODBC data sources**
  * **has all required ODBC drivers for desired connections**

### Folders and Files

* **log in to the Windows Server using the service account with administrative privileges**
* **create a dedicated folder ("tODBC Folder"), for example:**
  ```
  mkdir "c:\Program Files\Transpara\tODBC\"
  ```
* **put the installation kit from Transpara (odbcExtractorXXX.zip) into the tODBC folder**
* **extract all files in the archive into the tODBC folder**

## Command Line

**The following steps need to be performed from an administrator command window:**

* **open an administrator command window (cmd.exe) (right-click, run as Administrator)**
* **change directory to the tODBC Folder**

### Python

* **verify the correct version of Python is installed**
* **if required, install Python (3.9.1 is the minimum)**

  ```
  python -V
  python-3.9.1-amd64.exe /quiet InstallAllUsers=1 PrependPath=1 Include_test=0
  ```
* **Install required Python modules:**

  ```
  python -m pip install -r requirements.txt
  ```

### Create and Start Windows Services

* **create ODBC API Service**
  *Note: You will be prompted for service account credentials, tStore API URL and the desired TCP/IP port.*
  ```
  install_services
  ```

*Note: Examine the api.err, api.out, odbc.err and odbc.out files for troubleshooting issues with the API or the ODBC Extractor.*

# Data Sources

### Data Source Name (DSN)

**Configure one or more DSNs and ensure that they are correct by testing the connection. The DSN will be used to identify which data source should be used for any particular query in the ODBC Extractor.**

## Connect Strings

**It is also possible to use a connect string without a configured DSN. For example:**

* **Linux SQL Server**

```
Driver={ODBC Driver 17 for SQL Server}; Server=sqlserver.cadman.transpara.com; DataBase=demodata; UID=xxxxxx; PWD=xxxxxxxx
```

* **Windows SQL Server**

```
SQL ServerDriver={SQL Server}; Server=sqlserver; DataBase=demodata; Integrated Security=SSPI;
```

* **Linux PostgreSQL**

```
Driver={PostgreSQL Unicode};Server=10.10.0.224;Port=5435;Database=postgres;Uid=postgres;Pwd=BorgGoesLive!22;
```

## Additional Linux Drivers

**These have not been tested by should be compatible.**

* **Oracle**
  * **oracle-instantclient12.1-basiclite-12.1.0.2.0-1.x86_64.rpm - Oracle client libraries**
  * **oracle-instantclient12.1-odbc-12.1.0.2.0-1.x86_64.rpm - the ODBC driver**
* **MySQL**
  * **mysql-connector-odbc_8.0.32-1ubuntu22.10_amd64.deb**
* 

# Extractor Manager GUI

**This Windows application is used to configure, test and schedule ODBC queries to deliver data to tStore. **

## Main Form

**Screen elements are described in the table below from left to right and from top to bottom.**

| **Screen Element**         | **Description and Usage**                                                                                                                                                                                                                                             |
| -------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **ODBC Query**             | **Dropdown list containing the set of ODBC queries that have been configured.**                                                                                                                                                                                       |
| **Enabled**                | **Checkbox to indicate whether the ODBC query should be processed by the ODBC Extractor engine. If this is not checked, no data will be delivered to tStore. Note, it is not possible to enable a query until the query has been validated.**                         |
| **Connect String**         | **A text box containing the connect string for the selected query. Note that the connect string can be of several different including simply "dsn=dsnname"**                                                                                                          |
| **Test**                   | **A button to the right of the Connect String. Pressing this button will attempt to connect to the ODBC data source as specified in the connect string. The status bar will reflect the outcome of the connectivity test with "Connection successful" or otherwise.** |
| **Query Source**           | **SQL query to be presented to the ODBC data source. A query cannot be used until it is "validated", "enabled" and "saved".**                                                                                                                                         |
| **Column Aliases**         | **This grid displays the selection list with the tODBC interpretation of the column aliases (e.g., timestamp, field, label, measurement). Double click on any row to change the alias type for the selected column.**                                                 |
| **Substitution Variables** | **A list of the available substitution variables along with their resolved values at the time of query validation.**                                                                                                                                                  |
| **First Few Rows**         | **A handful of rows of actual data which are the the result of executing the ODBC query against the ODBC data source.**                                                                                                                                               |
| **Generated Metrics**      | **This grid indicates how the data will be represented within tStore. Note that it is possible to copy a "lookup" (for use with other tools) by highlighting a lookup and pressing Control-C.**                                                                       |
| **Buttons**                | **Cancel - Cancels all modifications made to the on-screen query and reloads the queries as currently stored in the database.**                                                                                                                                       |
|                                  | **Validate -**                                                                                                                                                                                                                                                        |
|                                  | **Delete -**                                                                                                                                                                                                                                                          |
|                                  | **Save -**                                                                                                                                                                                                                                                            |
|                                  | **Close -**                                                                                                                                                                                                                                                           |
| **Menu Bar**               | **File, New -**                                                                                                                                                                                                                                                       |
|                                  | **File, Save -**                                                                                                                                                                                                                                                      |
|                                  | **File, Save As -**                                                                                                                                                                                                                                                   |
|                                  | **File, Connect ODBC API -**                                                                                                                                                                                                                                          |
|                                  | **File, Export Queries -**                                                                                                                                                                                                                                            |
|                                  | **File, Quit -**                                                                                                                                                                                                                                                      |
|                                  | **Help, ABout -**                                                                                                                                                                                                                                                     |

## Typical Work Flows

### Creating a New Query

| **Action**                    | **Details** |
| ----------------------------------- | ----------------- |
| **Enter Connect String**      |                   |
| **Press Test**                |                   |
| **Enter Query Source**        |                   |
| **Press Validate**            |                   |
| **Adjust Column Aliases**     |                   |
| **Examine First Few Rows**    |                   |
| **Examine Generated Metrics** |                   |
| **Set Execution Interval**    |                   |
| **Enable Query**              |                   |
| **Save Query**                |                   |

### SQL Query Source

**In general, any SQL query can be used by the Transpara ODBC Extractor ("tODBC Queries"). All columns returned by tODBC queries ***must* be aliased using a specific two character prefix, described below.

### Connect String

### Execution Interval

### Column Aliases

**Transpara ODBC Extractor Queries require specific column aliases. These aliases indicate how that particular column should be interpreted by the Extractor.**

| **Column Alias Tag**     | **Meaning**                                                                                                                                                                                            | **Required**         |
| ------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | -------------------------- |
| **t**:*timestamp_name* | **Timestamp  column; This will be interpreted as the timestamp value.**                                                                                                                                | **One and only one** |
| **f**:*field_name*     | **Field column. Each field column represents a value to be stored in tStore. Multiple field columns can be configured, but there must be at least one.**                                               | **At least one.**    |
| **m**:*metric_name*    | **The measurement or metric name. This will be prepended to each field in creating the tStore metric.**                                                                                                | **Optional.**        |
| **l**:*label_name*     | **Labels are used to differentiate recordings and contain metadata about the recording. This may include a tagname, plant area, analysis type. It is also common to indicate the source of the data.** | **Optional.**        |

### Substitution Parameters

**Substitution parameters can be used anywhere in your SQL query, and as the name implies, will be replaced with the correct data when the query is executed.**

| **Parameter**      | **Description** |
| ------------------------ | --------------------- |
| **HOST**           |                       |
| **LAST_DATA_TIME** |                       |

#### SQL Best Practices

**It is a good idea to limit the number of rows that may be potentially returned by your SQL query. There is no limit to the number of values that can be stored in tStore (subject to disk space). Of course, the more rows returned, the longer it will take to process and digest.**

**Limiting the number of rows can be done with a subsitution parameter (LAST_DATA_TIME). It is also wise to include a ***limit* clause in your SQL to set the absolute maximum number of rows that may be returned.

**Note that the most recent data is returned by including an ***order by* clause in the SQL.

# Sample Queries

* **Transpara Extracted OSIsoft PI Tags (PostgreSQL)**

```
select
'pitags' as "m:pitags",
time as "t:time",
value as "f:value",
val(point_id) as "l:tagname",
val(server_id) as "l:server"
from
tcache
where
time > '{LAST_DATA_TIME}'
order by
time desc limit 30
```

* **Timescale Chunk Metadata (PostgreSQL)**

```
--
-- commented source
--
select
    'chunks' as "m:chunks",
    timeofday()::timestamptz as "t:time",
    hypertable_name as "l:tmetric",
    extract('epoch' from (max(range_end) - min(range_start)))/3600.0 as "f:chunk_span_total",
    count(*) as "f:chunk_count",
    '{HOST}' as "l:host"
from
    timescaledb_information.chunks
group by
    hypertable_name;
```

### three_consec

```
--
-- This demonstration query will look for three consecutive values
-- for cpu_usage_idle (for cpu-total)
--
SELECT
'cpu' as "m:cpu",
cpu as "l:cpu",
time as "t:time",
value as "f:three_consec"
FROM
(
SELECT
    val(cpu_id) cpu,
time,
value,
lag(value) OVER w value_1,
lag(value, 2) OVER w value_2
FROM
cpu_usage_idle
WHERE
time > current_timestamp - INTERVAL '10m'
    AND
val(cpu_id) = 'cpu-total'
WINDOW w AS (ORDER BY time)
) last_three
WHERE
value < 99.5
AND
value_1 < 99.5
AND
value_2 < 99.5
ORDER BY
time desc
```

* **Transpara Demo Data (SQL Server)**

```
select
[Name] as "m:tagname",
[Timestamp] as "t:Timestamp",
[Value] as "f:Value",
'{HOST}' as "l:source"
from
[TimeSeriesData] d,
[TimeSeriesTags] t
where
d.[ID] = t.[ID]
and
[Timestamp] between current_timestamp - 5.0/60.0/24.0 and current_timestamp
order by
[Timestamp] desc
```

* **Random data (PostgreSQL)**

```
SELECT
'Random' as "m:random",
'{HOST}' as "l:odbc_host",
current_database() as "l:db",
inet_server_addr() as "l:server",
time as "t:timestamp",
(random()*30)::int as "f:ivalue",
random()*80 - 40 as "f:fvalue"
FROM
generate_series(
current_timestamp - interval '5m',
current_timestamp,
INTERVAL '2 min') AS time;
```
