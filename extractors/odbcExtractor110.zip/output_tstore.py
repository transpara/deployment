# (C) Copyright 2022 Transpara LLC. All rights reserved.
#
#   To Do:
#       no need to save empty buffer over already empty buffer
#       change to buffer the raw lines as FIFO to support incremental save?
#       statistics endpoint? (in main.py)
#       fix timing calculation under windows (0.0)
#       update statistical metrics to new naming convention
#
#   tstore execd output plugin supporting bulking (clumping) of samples
#   for efficient writing
#
#
#   0.9.7
#       change parameter -m --metrics to -s --statistics
#   0.6.4
#       use .transpara metadata for automatic startup
#   0.6.3
#       get version number from environment variable (always matches .env)
#       allow specification of buffer_folder
#       do not write buffer if it is empty
#
#   December 8, 2022 - Inselbuch
#       automatic buffering upon write failure
#       dispense with shared memory variable for triggering buffering
#       switch buffer back to dictionary
#       so it will only have entries for each unique set of labels
#       and the samples lists will grow with time
#       unbuffers efficiently
#       start looking at the response codes for http requests that fail
#       buffering
#   December 2, 2022 - Inselbuch
#       move to make this one the default (over the golang version)
#       bulk up data for better throughput
#       incorporate v1/v2 metric definitions
#   March 15, 2022 - Inselbuch
#       disable buffering for now
#       future use case
#       support for Windows
#   February 15, 2022 - Inselbuch
#       use dictionary for muiltiple samples (speedy)
#   February 10, 2022 - Inselbuch
#       new module
#

from datetime import datetime, timedelta
import json
import sys
import os
import socket
import requests
from threading import Thread, Lock
import argparse
import multitimer
import time
import platform
import config
import pickle




######################################################
# generate some self-referential metrics for diagnosis
######################################################
def generateStatistics(nsent):

    labels = {}

    if not config.STATISTICS:
       return

    hostname = platform.node()

    ts = epochInt(time.time())
    td = datetime.now() - config.LAST_DATA_SENT

    # labels for several metrics
    labels["source"] = "output_tstore"
    labels["identity"] = config.IDENTITY
    labels["host"] = hostname

    ## a few metrics for self-diagnosis
    value = totalSamples(config.QUEUE)
    labels["__name__"] = 'transpara_queue_size'
    sample = [ts,value]
    enqueue(labels,sample)

    value = totalSamples(config.BUFFER)
    labels["__name__"] = 'transpara_buffer_size'
    sample = [ts,value]
    enqueue(labels,sample)

    try:
        value = float(nsent)/td.total_seconds()
    except:
        value = 0

    labels["__name__"] = 'transpara_metrics_per_second'
    sample = [ts,value]
    enqueue(labels,sample)

    return

def debugPrint(x):
    if config.DEBUG == True:
        print(x)
        sys.stdout.flush() 

################################ buffering
# for saving/restoring the buffer to disk
def saveBuffer():
    
    # the first time it goes empty, it DOES need to be written
    # if len(config.BUFFER) == 0:
    #     return datetime.now()
    
    fname = f'{config.IDENTITY}.bin'
    
    debugPrint(f'TEXT-{config.IDENTITY}-saving buffer...')
    f = open(fname,'wb')
    pickle.dump(config.BUFFER,f)
    f.close()
    return datetime.now()

def loadBuffer(): ######## this has never been executed (yet)
    buf = {}
    try:
        fname = f'{config.FOLDER}/{config.IDENTITY}.bin'
        f = open(fname,'rb')
        buf = pickle.load(f)
        f.close()
    except:
        pass
    return buf

#### if the key alread exists, extend the list samples
def moveQueueToBuffer():
    while len(config.QUEUE) > 0:
        x = config.QUEUE.popitem()
        key = x[0]
        try:
            list_of_samples = config.BUFFER[key]
            list_of_samples.extend(x[1])
        except:
            config.BUFFER[key] = x[1]
    return

def totalSamples(qdict):
    sampleCount = 0
    for labels,samples in qdict.items():
        sampleCount += len(samples)
    return sampleCount

# promscale does not like certain characters
# I don't like them either
def nicer(notnice):
    x = notnice.lower()
    x = x.replace(' ','_')
    x = x.replace('.','_')
    x = x.replace('/','_')
    x = x.replace('-','_')

    return x

# convert time to promscale expectation
def epochInt(etime):
    return int(etime*1000.0)

# ******************************************************************************
# enqueue - add a sample to the Queue
#   if there is already one or more samples for a set of labels
#       the sample is added to the list of existing samples
#   if there is not, a new dictionary entry is created for the set of labels
# ******************************************************************************
def enqueue(labels,sample):
    config.MUTEX.acquire()
    dkey = json.dumps(labels)
    try:
        list_of_samples = config.QUEUE[dkey]
        list_of_samples.append(sample)
    except:
        config.QUEUE[dkey]=[sample]
    finally:
        config.MUTEX.release()

    return

# ******************************************************************************
# makeSendBuffer - convert dictionary to sjson and return number of samples
# ******************************************************************************
def makeSendBuffer(x):
    sjson = ""
    k=0
    for labels,samples in x.items():
        j={"labels" : json.loads(labels), "samples" : samples}
        k += len(samples)
        sjson += json.dumps(j)
    return sjson,k


# ******************************************************************************
# send - send a tstore-api data structure to the api using http POST
# ******************************************************************************
def send(d):
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    try:
        r=requests.request(
            method='POST',
            url=config.TSTORE_API_URL,
            headers=headers,
            data=d,
            verify=False,
            timeout=3
        )
        return r.status_code
    except Exception as er: # could be more granular in the future or maybe there's some kind of integer?
        return -999

############################## asynchronous flushing of the queue
#
#   we will flush the queue when a timer has expired
#   or when the depth of the queue reaches a limit
#
def flushQueue(why):

    config.TIMER.stop()

    # tracking how many actually go
    samplesSent = 0

    # show statistics
    before = 'TEXT-{}-{}, Processing Buffer(n)/Queue(n)  {}({})/{}({})'.format(
        config.IDENTITY,
        why,
        len(config.BUFFER),
        totalSamples(config.BUFFER),
        len(config.QUEUE),
        totalSamples(config.QUEUE)
        )

    # queue performance metrics, self aware
    # identity (must be unique per node)
    # node
    # 
    # if it's time to do it, do it
    if (datetime.now() - config.LAST_BUFFER_SAVE) > config.BUFFER_SAVE_FREQUENCY:
        config.LAST_BUFFER_SAVE = saveBuffer()        

    ################################################# Send the Queue
    config.MUTEX.acquire() ####################### LOCK
    sjson,numSamples = makeSendBuffer(config.QUEUE)
    if numSamples > 0:
        resp = send(sjson)
        # if successful we can dump the queue
        if resp == 200:
            samplesSent += numSamples
            config.LAST_DATA_SENT = datetime.now()
            config.QUEUE.clear()
        else:
            debugPrint('Could not send data, adding to buffer...')
            moveQueueToBuffer()
    config.MUTEX.release() ####################### UNLOCK

    ################################################# Send the Buffer
    config.MUTEX.acquire() ####################### LOCK
    sjson, numSamples = makeSendBuffer(config.BUFFER)
    if numSamples > 0:
        resp = send(sjson)
        # if successful we can dump the BUFFER, if not we do nothing
        if resp == 200:
            samplesSent += numSamples
            config.LAST_DATA_SENT = datetime.now()
            config.BUFFER.clear()
            config.LAST_BUFFER_SAVE = saveBuffer() # cause it's empty now
        else:
            debugPrint(resp)
    
    config.MUTEX.release() ####################### UNLOCK

    # show statistics
    after = 'TEXT-{}-{}, Buffer(n)/Queue(n)  {}({})/{}({})'.format(
        config.IDENTITY,
        why,
        len(config.BUFFER),
        totalSamples(config.BUFFER),
        len(config.QUEUE),
        totalSamples(config.QUEUE)
        )

    if samplesSent > 0:
        debugPrint(before)
    debugPrint(after)

    # some useful metrics (if enabled)
    generateStatistics(samplesSent)

    config.TIMER.start()

    return
####################################
#
#       PROCESS LINE (incoming JSON in telegraf format)
#
####################################
def processLine(rawLine,live=True):
    # if rawLine == "":
    #     sys.exit()

    # if len(rawLine) == 0:
    #     sys.exit()

    # if rawLine == "quit\n":
    #     sys.exit
    
    labels={}

    # this should not be required, but we seem to be getting malformed data from time to time
    try:
        line = json.loads(rawLine)
    except Exception as ex:
        debugPrint("TEXT-I-Invalid data received - {}\n\t({})".format(rawLine,ex))
        return 1, []

    # pick apart the line, convert to json and construct the labels, etc.
    ts = epochInt(line['timestamp'])
    tags = line['tags']
    fields = line['fields']
    measurement = line['name']

    # everybody treats tags as Labels
    for tag,value in tags.items():
        labels[tag] = value
        
    # for Metric Type 1, we create a sample for EACH field
    if config.METRIC_TYPE ==1:
        for field, value in fields.items():
            if nicer(field) == "value":
                metric_name = "{}".format(measurement)
            else:
                metric_name = "{}_{}".format(measurement,nicer(field))
            labels["__name__"] = metric_name
            sample = [ts,value]
            if live:
                enqueue(labels,sample)

    # for Metric Type 2, we treat the fields as additional labels
    else:
        labels["__name__"] = nicer(measurement)
        for field, value in fields.items():
            labels[field]=value    
        sample = [ts,value]
        if live:
            enqueue(labels,sample)
    
    # if enough samples have accumulated, send them
    # (note, flushQueue also gets called on a time)
    if totalSamples(config.QUEUE) > config.QUEUE_DEPTH:
        flushQueue(['depth'])

    return 0

def startTimer():
    # start flushing the queue every EXPIRE_SECONDS
    config.TIMER = multitimer.MultiTimer(
        interval=config.EXPIRE_SECONDS,
        function=flushQueue,args=['timer'],
        runonstart=False
    )
    config.TIMER.start()

    return

################################ MAIN

if __name__ == "__main__":
    
    # if this is the main program, it will process the arguments here
    # if it is being called as a module, the parent is responsible for populating the arguments
    flags = argparse.ArgumentParser()
    flags.add_argument('-u','--url',dest='url',type=str,required=True)
    flags.add_argument('-t','--metric_type',dest='metric_type',type=int,required=True)
    flags.add_argument('-d','--debug',dest='debug',action='store_true')
    flags.add_argument('-q','--queue_depth',dest='queue_depth',default=10000)
    flags.add_argument('-e','--expire_seconds',type=int,dest='expire_seconds',default=120)
    flags.add_argument('-i','--identity',type=str,dest='identity',default='telegraf')
    flags.add_argument('-s','--statistics',dest='statistics',action='store_true')
    #flags.add_argument('-f','--folder',dest='folder',type=str,default='/app/data/')

    # if the arguments are not correct, the program will exit with a message
    args = flags.parse_args()

    # GLOBAL VARIABLES
    config.TSTORE_API_URL = args.url
    config.DEBUG = (args.debug == True)
    config.METRIC_TYPE = args.metric_type
    config.QUEUE_DEPTH = args.queue_depth
    config.EXPIRE_SECONDS = args.expire_seconds
    config.IDENTITY=args.identity
    config.STATISTICS=args.statistics
    #config.FOLDER=args.folder

    config.QUEUE = {} # dictionary so we can easily merge multiple samples for the same series
    config.BUFFER = {} # just like the queue except it might have longer lists of samples
    config.MUTEX = Lock()
    config.BUFFER_SAVE_FREQUENCY = timedelta(minutes=2)
    config.LAST_BUFFER_SAVE = datetime.now()
    config.LAST_DATA_SENT = datetime.now()
    config.UNBUFFERING = False
    config.QTOTAL = 0
    config.BTOTAL = 0
    config.VERSION = os.getenv('extractor_version','0.6.x')

    debugPrint(f'Starting Extractor_Telegraf {config.VERSION}')

    # attempt to load a buffer file (if it exists from previous run)
    config.BUFFER = loadBuffer()

    startTimer()

    # process endless output lines from telegraf
    while True:

        # initialize the labels each line
        labels = {}

        # get a line from telegraf stdout
        line = sys.stdin.readline()

        processLine(line)


   
     

