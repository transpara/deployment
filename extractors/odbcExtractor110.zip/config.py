# (C) Copyright 2022 Transpara LLC. All rights reserved.
#
#
#   tstore execd output plugin supporting bulking (clumping) of samples
#   for efficient writing
#
#



from threading import Thread, Lock
from datetime import datetime, timedelta
import multitimer

# GLOBAL VARIABLES
TSTORE_API_URL = ""
DEBUG = False
METRIC_TYPE = 1
QUEUE_DEPTH = 500
EXPIRE_SECONDS = 60
IDENTITY = ""
STATISTICS = True
TIMER = None

QUEUE = {}
BUFFER = {}
MUTEX = Lock()
BUFFER_SAVE_FREQUENCY = timedelta(minutes=5)
LAST_BUFFER_SAVE = datetime.now()
LAST_DATA_SENT = datetime.now()
UNBUFFERING = False
QTOTAL = 0
BTOTAL = 0
FOLDER = ""
VERSION="1.1.0"

