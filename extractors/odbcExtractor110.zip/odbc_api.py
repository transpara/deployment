#
# Transpara ODBC Extractor Configurator Web API
#
#  To Do:
#     tcp/ip port should be configurable
#     do not allow data from the future (optional)
#     default values for parameters (good idea)
#     users should be identical? any need to specify the user when /installService
#     start services when they are created
#
#  1.0.0
#     add "enabled" to edit/save
#  0.9.8
#     switch to connect strings
#     connect/disconnect each time
#     remove -f parameter
#  0.9.7
#     include credentials with each query
#     /DSNup
#  0.9.1
#     if there is no database file, create one
#  0.9.0
#     test of arbitrary query (before it is saved)
#     return status of false when testing query and returning error
#  0.8.1
#     /tStoreReachable, returns JSON
#     use the single folder for every path
#     tags to organize FastAPI page
#     get version from somewhere, not hard coded
#  0.8.0
#     query validation
#        must have:
#           one and only one "t:"
#           one or more "f:"
#     /start_service
#     /stop_service
#     /installService
#     /removeService
#     /testQuery
#     /addQuery
#     /listQueries
#  0.7.0
#     /status

import uvicorn
from fastapi import FastAPI, APIRouter, Body
from fastapi.responses import RedirectResponse
from typing import Union
import subprocess
import os
from pydantic import BaseModel, SecretStr
import re
from datetime import datetime, timedelta
#import argparse
import pickle
import json
import odbc

# global variables
QUERIES = {}
VERSION = '1.1.0'

router = APIRouter()
root_router = APIRouter()

app = FastAPI(
title="Transpara ODBC Extractor API",
description="Extract data from any ODBC data source and deposit into tStore.",
openapi_url="/api/v1/openapi.json",
version = VERSION
)

#flags = argparse.ArgumentParser()
#flags.add_argument('-p','--port',dest='port',type=str,required=False)

# if the arguments are not correct, the program will exit with a message
#args2 = flags.parse_args()

# try:
#    PORT = int(args2.port)
# except:
#    PORT = 5000
PORT = 5000

def fixPath(p):
   lastChar = p[-1]
   if lastChar not in ["\\","/"]:
      return p + '/'
   else:
      return p

# # make sure it has a slash at the end
# FOLDER = fixPath(FOLDER)

class QUERY_SOURCE(BaseModel):
   source : str
  
def loadDB():
   queries = {}
   try:
      f = open('app/data/odbc.db','rb')
      queries = pickle.load(f)
      f.close()
   except Exception as ex:
      saveDB(queries)
      print(ex)
   return queries
   
def saveDB(qdb):
   f = open('app/data/odbc.db','wb')
   pickle.dump(qdb,f)
   f.close()

@root_router.get("/",include_in_schema=False)
async def root():
    return RedirectResponse(url="/docs")

def installed(command:str):   
   cmd = f'{command} -?'
   
   try:
      proc=subprocess.run(cmd, shell=True, check=True, stdout=subprocess.PIPE)
      results = proc.stdout.decode('utf-8')
      results=results.strip()
   except subprocess.CalledProcessError as perr:
      return False

   return True
   
@router.get("/listTables",tags=["ODBC Engine"])
def listTables(cstr:str):
   response,tables = odbc.listTables(cstr)
   
   return {"tables" : tables, "response" : response }
   
@router.get("/DSNup",tags=["Queries"])
def DSNup(cstr:str):
   result = odbc.testDSN(cstr)  
   return result
   
@router.get("/listDrivers",tags=["ODBC Engine"])
def listDrivers():
   return {"status" : "True" , "drivers" : odbc.listDrivers()}


@router.get("/tStoreReachable",tags=["ODBC Engine"])
def tStoreReachable(tstore_url:str):
   cmd = f'curl {tstore_url}/up'   
   try:
      proc=subprocess.run(cmd, shell=True, check=True, stdout=subprocess.PIPE)
   except subprocess.CalledProcessError as perr:
      return {"status" : False} 
   return {"status" : True}

@router.put("/addQuery",tags=["Queries"])
def addQuery(
   name: str,
   cstr: str,
   source: QUERY_SOURCE,
   interval: timedelta,
   enabled: bool = False
   ):
   QUERIES=loadDB()
   
   try:
      x = QUERIES[name]
      return {"status" : "query by that name already exists", "result_code" : 1}
   except:
      pass
   
   QUERIES[name] = {
         "cstr" : cstr,
         "query" : source.source,
         "last_data" : None,
         "interval" : interval,
         "last_execution" : None,
         "enabled" : enabled
      }      
   saveDB(QUERIES)    
   return {"status" : "Query added to database.", "result_code" : 0}


@router.put("/editQuery",tags=["Queries"])
def editQuery(
   name: str,
   cstr: str,
   source: QUERY_SOURCE,
   interval: timedelta,
   enabled: bool = False
   ): 
   QUERIES=loadDB()

   
   try:
      existing = QUERIES[name]
   except:
      return {"status" : "No query by that name."}
   
   QUERIES[name] = {
         "cstr" : cstr,
         "query" : source.source,
         "last_data" : None,
         "interval" : interval,
         "last_execution" : None,
         "enabled" : enabled
      }      
   saveDB(QUERIES)    
   return {"status" : "Query updated."}

@router.delete("/deleteQuery",tags=["Queries"])
def deleteQuery(name : str):
   QUERIES=loadDB()
   try:
      del QUERIES[name]
      saveDB(QUERIES)
      return {"status" : "Query deleted from database."}
   except:
      return {"status" : "No such query."}
      

@router.get("/listQueries",tags=["Queries"])
def listQueries():
   QUERIES=loadDB()
   #print("QUERIES = ",QUERIES)
   return QUERIES


@router.put("/testQuery",tags=["Queries"])
def testQuery(
   cstr: str,
   source: QUERY_SOURCE
):
   
   # run the test, validate the results, assemble into JSON and return it for the GUI
   columns,rows,subvs,query,testSamples,er = odbc.testExecute(cstr,source.source)

   if er is not None:
      ers = "{}".format(er)
      return {
         "status": False,
         "query" : "",
         "columns" : "", 
         "fewrows" : "",
         "substitution_variables" : "",
         "response" : ers
      }

   if len(columns) == 0:
      return {"status": False,
         "query" : "",
         "columns" : "", 
         "fewrows" : "",
         "substitution_variables" : "",
         "response" : "Invalid query. No columns selected."
      }

   # examine the columns for validity
   foundTime = False
   foundField = False
   OnlyOneTime = True
   for c in columns:
      if 't:' in c:
         if foundTime:
            OnlyOneTime = False
         foundTime = True
         continue
      if 'f:' in c:
         foundField = True
         continue
         
   Valid = foundTime and foundField and OnlyOneTime

   if Valid:
      ers = "Valid"
   else:
      ers = "Malformed query. Must have one and only one timestamp (t:<column>) plus at least one field (f:<column>)."
   
   
   return {
      "status": Valid,
      "query" : query,
      "columns" : columns, 
      "fewrows" : rows,
      "substitution_variables" : subvs,
      "testSamples" : testSamples,
      "response" : ers
   }

app.include_router(router, prefix="/api/v1")
app.include_router(root_router)


###################### MAIN
if __name__ == "__main__":
      
   uvicorn.run("odbc_api:app", host="0.0.0.0", port=PORT, log_level="info",reload=True)



